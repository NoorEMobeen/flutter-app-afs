final String signIn = 'signin';
final String signUp = 'signup';
final String splashScreen = 'splashscreen';
